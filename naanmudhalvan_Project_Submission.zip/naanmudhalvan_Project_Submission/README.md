# melodi - Melodies for every moment.

This is a simple django project which is developed using the DJango framework.
It has the following features,
1. Login
2. Register
3. Browse for Music
4. Change the Playback Speed
5. Download the Track.
